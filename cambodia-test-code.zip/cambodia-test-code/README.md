 # By Vineet kumar Pathak   ##


 
 # Step1 : -  Do the git Clone .. Url (https://github.com/vineet19/Cambodia-test-code/) .... from git hub

 # please add node_modules folder , bcz for space in git hub was very so its removed while uploading

 #  change in package json  --   "start": "react-scripts --openssl-legacy-provider start",

 #  Step2 : - Do the npm install

  #  Step3 : - npm start


#  http://localhost:3000/   -- it will execute application on the web server..
