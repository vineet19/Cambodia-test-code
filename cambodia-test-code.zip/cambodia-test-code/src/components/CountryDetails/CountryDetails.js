import { useParams } from 'react-router';
import { useNavigate } from 'react-router-dom';
import useCountries from 'Providers/CountriesProvider';
import { useMemo } from 'react';
import SingleInfo from 'components/SingleInfo/SingleInfo';
import BorderCountry from 'components/BorderCountry/BorderCountry';
import { StyledBorderCountries, BorderCountryList, Info, InfoWrapper, StyledButton, Wrapper } from './CountryDetails.styles';

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

const CountryDetails = () => {
  const { name } = useParams();
  let navigate = useNavigate();
  const { findCountryByName, findByAltSpelling } = useCountries();

  const handleBackButton = () => {
    navigate(-1);
  };

  const country = useMemo(() => findCountryByName(name), [findCountryByName, name]);

  const prepareLanguages = (languages) => {
    if (!languages) return;
    return Object.values(languages);
  };

  const prepareCurrencies = (currency) => {
    if (!currency) return;
    return Object.values(currency).map((curr) => curr.name);
  };
    // code by vineet kumar
  return (
    <Wrapper>
      <StyledButton onClick={handleBackButton}>Back</StyledButton>
      {country ? (
        <InfoWrapper>
          <img src={country.flags.svg} alt={country.common} />
          <Info>
            <h2>{country.name.common}</h2>
            <div> 
              <SingleInfo title="Native Country Name" stat={Object.values(country.name.nativeName)[0]?.official} />
               <SingleInfo title="Country Code(2 char) " stat={country.cca2} />
               <SingleInfo title="Country Code(3 char)" stat={country.cca3} />
            </div>
             
            {country.borders ? (
              <StyledBorderCountries>
                <div>Alternative Countries:</div>
                <BorderCountryList>
                  {country.borders.map((altSpelling) => {
                    const countryByAlt = findByAltSpelling(altSpelling);
                    return <BorderCountry name={countryByAlt.name.common} key={countryByAlt.name.common} />;
                  })}
                </BorderCountryList>
              </StyledBorderCountries>
            ) : null}
          </Info>
        </InfoWrapper>
      ) : (
        <h2>Loading...</h2>
      )}
    </Wrapper>
  );
};

export default CountryDetails;
