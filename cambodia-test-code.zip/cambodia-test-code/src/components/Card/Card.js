import { Wrapper } from './Card.styles';
import { StyledLink } from './Card.styles';

const Card = ({ country }) => {
  const {
    name: { common },
    capital,
    continents: [continet],
    population,
    flags: { svg },
  } = country;

  return (
    <Wrapper>
      <StyledLink to={`country/${common}`}>
        <img src={svg} alt={common} />
        <div>
        <p>
         <span>Country :</span> {common}
         </p>
           
          <p>
           </p>
        </div>
      </StyledLink>
    </Wrapper>
  );
};

export default Card;
